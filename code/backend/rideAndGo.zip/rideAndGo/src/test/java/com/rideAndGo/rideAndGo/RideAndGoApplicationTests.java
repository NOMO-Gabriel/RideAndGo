package com.rideAndGo.rideAndGo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RideAndGoApplicationTests {

	@Test
	void contextLoads() {
	}

}
